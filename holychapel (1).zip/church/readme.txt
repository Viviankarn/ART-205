Church WordPress theme
----------------------
Church is the default Responsive HTML5 Omega child theme for WordPress. Inherit all Omega parent theme capabilities, and reveal big fat footer widget areas

Created by themehall.com, http://themehall.com


License
-------
Church WordPress theme, Copyright (C) 2013 themehall.com
Church WordPress theme is licensed under the GPL.

TinyNav.js is licensed under the MIT license. Copyright (c) 2011-2012 Viljami Salminen.


Install
-------
1. Download "omega" parent theme from http://wordpress.org/themes/omega
2. Go to your WordPress dashboard and select Appearance > Install, click Upload link.
3. Upload both Omega and this child theme, then activate the child theme


Changelog
---------
0.7.7 - 2016-7-22
- update google font url for https support

0.7.6 - 2016-1-20
- Home banner is back

0.7.5 - 2016-1-12
- fix featured image

0.7.4 - 2015-12-11
- update style.css
- fix header issue

0.7.3 - 2015-9-21
- add Text domain 
- change link color

0.7.2 - 2015-6-1
- fixed form element styling on New safari and Chrome

0.7.1 - 2015-3-31
- update style.css

0.7.0 - 2015-3-31
- Introduce Full Width and left sidebar page template to replace theme Layout option

0.6.1 - 2014-7-16
- update style.css

0.5.3 - 2014-5-21
- update style.css

0.5.2 - 2014-5-5
- update style.css

0.5.1 - 2014-4-17
- update style.css
- remove page-left-sidebar.php (sorry)

0.3.1 - 2014-4-14
- update style.css
- add page-left-sidebar.php

0.3.1 - 2014-2-19
- update style.css

0.3.0 - 2014-2-19
- add woocommerce support

0.2.9 - 2014-2-11
- add featured Image option as static front page header image 

0.2.8 - 2014-1-11
- clean up css

0.2.7 - 2013-12-13
- add home banner widget
- add responsive tag

0.2.6 - 2013-12-11
- update widget priority

0.2.5 	2013-11-22
- Add Omega 0.9.0 awesomeness

0.2.4 	2013-10-31
- Add header image link

0.2.3 	2013-10-22
- add ability to disable header image on inner pages
- fix mobile menu style, better UX

0.2.2 	2013-10-22
- add inner page header image via featured image

0.2.1 	2013-10-14
- remove function check
- fixed comment field style

0.1.1 	2013-10-14
- change accent and footer colors to primary and secondary
- fixed css issues

0.1.0	2013-10-13
- First release